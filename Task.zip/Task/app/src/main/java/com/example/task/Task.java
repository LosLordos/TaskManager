package com.example.task;

public class Task {

    private static String Title;
    private static String Content;

    public Task() {

    }

    public static String getTitle() {
        return Title;
    }

    public static void setTitle(String title) {
        Title = title;
    }

    public static String getContent() {
        return Content;
    }

    public static void setContent(String content) {
        Content = content;
    }

    public Task(String title, String content) {
        Title = title;
        Content = content;
    }

}
