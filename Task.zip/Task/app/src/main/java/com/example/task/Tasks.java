package com.example.task;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Tasks extends AppCompatActivity{

    private static final String PREFS_NAME = "NotePrefs";
    private static final String KEY_NOTE_COUNT = "NoteCount";

    private LinearLayout taskContainer;
    private List<Task> taskList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);

        taskList = new ArrayList<>();
        
        

        Button SaveButton = findViewById(R.id.saveButton);
        Button BackButton = findViewById(R.id.backButton);
        taskContainer = findViewById(R.id.TaskContainer);


        SaveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTask();
            }
        });

        Button backButton = (Button) findViewById(R.id.backButton);
        BackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Tasks.this , MainActivity.class));
            }
        });

        DisplayTasks();
        LoadTasksFromPreferences();
    }

    private void DisplayTasks() {
        for(Task task : taskList){
            createTaskView(task);
        }
    }

    private void LoadTasksFromPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME,MODE_PRIVATE);
        int taskCount = sharedPreferences.getInt(KEY_NOTE_COUNT,0);

        for(int i = 0; i < taskCount; i++ ){
            String title = sharedPreferences.getString("task_title" + i, "");
            String content = sharedPreferences.getString("task_content" + i, "");

            Task task = new Task();
            Task.setTitle(title);
            Task.setContent(content);

            taskList.add(task);
        }

    }

    private void saveTask() {
        EditText titleEditText = findViewById(R.id.TaskTitle);
        EditText contentEditText = findViewById(R.id.TaskContent);


        String title = titleEditText.getText().toString();
        String content = contentEditText.getText().toString();

        if(!title.isEmpty() && !content.isEmpty()){
            Task task = new Task();
            task.setContent(content);
            task.setTitle(title);


            taskList.add(task);
            saveTaskToPreferences();

            createTaskView(task);
            clearInputFields();


        }

    }

    private void clearInputFields() {

        EditText titleEditText = findViewById(R.id.TaskTitle);
        EditText contentEditText = findViewById(R.id.TaskContent);

        titleEditText.getText().clear();
        contentEditText.getText().clear();
    }

    private void createTaskView(final Task task) {
        View taskView = getLayoutInflater().inflate(R.layout.task_item, null);
        TextView titleTextView = taskView.findViewById(R.id.taskTitleView);
        TextView contentTextView = taskView.findViewById(R.id.contentTextView);

        titleTextView.setText(Task.getTitle());
        contentTextView.setText(Task.getContent());

        taskView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                showDeleteDialog(task);
                return true;
            }
        });

        taskContainer.addView(taskView);

    }

    private void showDeleteDialog(final Task task) {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete this note?");
        builder.setMessage("Are u sure you want delete this note?");
        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                deleteTaskAndRefresh(task);

            }
        });
        builder.setNegativeButton("Cancel",null);
        builder.show();
    }

    private void deleteTaskAndRefresh(Task task) {

        taskList.remove(task);
        saveTaskToPreferences();
        refreshTaskView();

    }

    private void refreshTaskView() {
        taskContainer.removeAllViews();
        DisplayTasks();
    }


    private void saveTaskToPreferences() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putInt(KEY_NOTE_COUNT, taskList.size());
        for(int i = 0; i < taskList.size(); i++){
            Task task = taskList.get(i);
            editor.putString("task_title" + i, task.getTitle());
            editor.putString("task_content" + i, task.getContent());
        }
        editor.apply();

    }


}